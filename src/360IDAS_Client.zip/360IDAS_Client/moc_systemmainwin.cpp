/****************************************************************************
** Meta object code from reading C++ file 'systemmainwin.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "Window/systemmainwin.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'systemmainwin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SystemMainWin_t {
    QByteArrayData data[37];
    char stringdata0[590];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SystemMainWin_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SystemMainWin_t qt_meta_stringdata_SystemMainWin = {
    {
QT_MOC_LITERAL(0, 0, 13), // "SystemMainWin"
QT_MOC_LITERAL(1, 14, 11), // "logoutSigal"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 32), // "on_videoRecordtoolButton_clicked"
QT_MOC_LITERAL(4, 60, 17), // "videoResearchSlot"
QT_MOC_LITERAL(5, 78, 11), // "SEARCHREST*"
QT_MOC_LITERAL(6, 90, 16), // "videoResearchRes"
QT_MOC_LITERAL(7, 107, 32), // "on_drivingModetoolButton_clicked"
QT_MOC_LITERAL(8, 140, 32), // "on_reverseModetoolButton_clicked"
QT_MOC_LITERAL(9, 173, 29), // "on_birdViewtoolButton_clicked"
QT_MOC_LITERAL(10, 203, 34), // "on_featureRecordtoolButton_cl..."
QT_MOC_LITERAL(11, 238, 17), // "imageResearchSlot"
QT_MOC_LITERAL(12, 256, 15), // "IMAGESERCHREST*"
QT_MOC_LITERAL(13, 272, 12), // "imageSearRes"
QT_MOC_LITERAL(14, 285, 34), // "on_systemSettingtoolButton_cl..."
QT_MOC_LITERAL(15, 320, 9), // "playVideo"
QT_MOC_LITERAL(16, 330, 4), // "path"
QT_MOC_LITERAL(17, 335, 8), // "frameNum"
QT_MOC_LITERAL(18, 344, 9), // "videoName"
QT_MOC_LITERAL(19, 354, 12), // "DrivingVideo"
QT_MOC_LITERAL(20, 367, 3), // "Mat"
QT_MOC_LITERAL(21, 371, 5), // "frame"
QT_MOC_LITERAL(22, 377, 11), // "autoCapture"
QT_MOC_LITERAL(23, 389, 16), // "ReverseVideoShow"
QT_MOC_LITERAL(24, 406, 14), // "BirdEyeVideoRT"
QT_MOC_LITERAL(25, 421, 5), // "effec"
QT_MOC_LITERAL(26, 427, 6), // "camera"
QT_MOC_LITERAL(27, 434, 16), // "return2VideoList"
QT_MOC_LITERAL(28, 451, 14), // "return2PIcList"
QT_MOC_LITERAL(29, 466, 20), // "on_logoutBtn_clicked"
QT_MOC_LITERAL(30, 487, 29), // "on_pic_listWidget_itemClicked"
QT_MOC_LITERAL(31, 517, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(32, 534, 4), // "item"
QT_MOC_LITERAL(33, 539, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(34, 561, 10), // "logoutSlot"
QT_MOC_LITERAL(35, 572, 4), // "flag"
QT_MOC_LITERAL(36, 577, 12) // "restartBirdT"

    },
    "SystemMainWin\0logoutSigal\0\0"
    "on_videoRecordtoolButton_clicked\0"
    "videoResearchSlot\0SEARCHREST*\0"
    "videoResearchRes\0on_drivingModetoolButton_clicked\0"
    "on_reverseModetoolButton_clicked\0"
    "on_birdViewtoolButton_clicked\0"
    "on_featureRecordtoolButton_clicked\0"
    "imageResearchSlot\0IMAGESERCHREST*\0"
    "imageSearRes\0on_systemSettingtoolButton_clicked\0"
    "playVideo\0path\0frameNum\0videoName\0"
    "DrivingVideo\0Mat\0frame\0autoCapture\0"
    "ReverseVideoShow\0BirdEyeVideoRT\0effec\0"
    "camera\0return2VideoList\0return2PIcList\0"
    "on_logoutBtn_clicked\0on_pic_listWidget_itemClicked\0"
    "QListWidgetItem*\0item\0on_pushButton_clicked\0"
    "logoutSlot\0flag\0restartBirdT"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SystemMainWin[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  120,    2, 0x08 /* Private */,
       4,    1,  121,    2, 0x08 /* Private */,
       7,    0,  124,    2, 0x08 /* Private */,
       8,    0,  125,    2, 0x08 /* Private */,
       9,    0,  126,    2, 0x08 /* Private */,
      10,    0,  127,    2, 0x08 /* Private */,
      11,    1,  128,    2, 0x08 /* Private */,
      14,    0,  131,    2, 0x08 /* Private */,
      15,    3,  132,    2, 0x08 /* Private */,
      19,    1,  139,    2, 0x08 /* Private */,
      22,    0,  142,    2, 0x08 /* Private */,
      23,    1,  143,    2, 0x08 /* Private */,
      24,    2,  146,    2, 0x08 /* Private */,
      27,    0,  151,    2, 0x08 /* Private */,
      28,    0,  152,    2, 0x08 /* Private */,
      29,    0,  153,    2, 0x08 /* Private */,
      30,    1,  154,    2, 0x08 /* Private */,
      33,    0,  157,    2, 0x08 /* Private */,
      34,    1,  158,    2, 0x0a /* Public */,
      36,    0,  161,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::QString,   16,   17,   18,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 20,   25,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 31,   32,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   35,
    QMetaType::Void,

       0        // eod
};

void SystemMainWin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SystemMainWin *_t = static_cast<SystemMainWin *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->logoutSigal(); break;
        case 1: _t->on_videoRecordtoolButton_clicked(); break;
        case 2: _t->videoResearchSlot((*reinterpret_cast< SEARCHREST*(*)>(_a[1]))); break;
        case 3: _t->on_drivingModetoolButton_clicked(); break;
        case 4: _t->on_reverseModetoolButton_clicked(); break;
        case 5: _t->on_birdViewtoolButton_clicked(); break;
        case 6: _t->on_featureRecordtoolButton_clicked(); break;
        case 7: _t->imageResearchSlot((*reinterpret_cast< IMAGESERCHREST*(*)>(_a[1]))); break;
        case 8: _t->on_systemSettingtoolButton_clicked(); break;
        case 9: _t->playVideo((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 10: _t->DrivingVideo((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 11: _t->autoCapture(); break;
        case 12: _t->ReverseVideoShow((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 13: _t->BirdEyeVideoRT((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2]))); break;
        case 14: _t->return2VideoList(); break;
        case 15: _t->return2PIcList(); break;
        case 16: _t->on_logoutBtn_clicked(); break;
        case 17: _t->on_pic_listWidget_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 18: _t->on_pushButton_clicked(); break;
        case 19: _t->logoutSlot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->restartBirdT(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (SystemMainWin::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SystemMainWin::logoutSigal)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject SystemMainWin::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SystemMainWin.data,
      qt_meta_data_SystemMainWin,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SystemMainWin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SystemMainWin::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SystemMainWin.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int SystemMainWin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}

// SIGNAL 0
void SystemMainWin::logoutSigal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
