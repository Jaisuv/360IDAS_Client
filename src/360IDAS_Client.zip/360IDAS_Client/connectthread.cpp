#include "connectthread.h"

ConnectThread::ConnectThread()
{

}
