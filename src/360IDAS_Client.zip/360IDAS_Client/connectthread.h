#ifndef CONNECTTHREAD_H
#define CONNECTTHREAD_H


class ConnectThread
{
public:
    ConnectThread();
};

#endif // CONNECTTHREAD_H
